import http from 'http';
import dotenv from 'dotenv';
import { Server } from 'socket.io';
import mongoose from 'mongoose';

// تحميل متغيرات البيئة قبل أي شيء
dotenv.config();

// تصحيح مسار app (تأكد من مكانه سواء في src/app.js أو src/utils/app.js)
import app from './src/utils/app.js'; 
import connectDB from './src/config/db.js';

// استيراد معالجات الـ Socket
import chatHandler from './src/sockets/chatHandler.js';
import callHandler from './src/sockets/callHandler.js';

const PORT = process.env.PORT || 5000;
const server = http.createServer(app);

// إعداد خادم WebSockets
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

io.on('connection', (socket) => {
  chatHandler(io, socket);
  callHandler(io, socket);
});

// بدء التشغيل
const startServer = async () => {
  try {
    await connectDB();
    server.listen(PORT, () => {
      console.log(`Server running in \({process.env.NODE_ENV || 'development'} mode on port\){PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Graceful Shutdown
const gracefulShutdown = (signal) => {
  console.log(`${signal} signal received: closing HTTP server`);
  server.close(async () => {
    console.log('HTTP server closed');
    try {
      await mongoose.connection.close(false);
      console.log('Database connection closed');
      process.exit(0);
    } catch (err) {
      console.error('Error during shutdown:', err);
      process.exit(1);
    }
  });

  setTimeout(() => {
    console.error('Forcing shutdown after timeout');
    process.exit(1);
  }, 10000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

process.on('unhandledRejection', (err) => {
  console.error('UNHANDLED REJECTION! Shutting down...', err);
  server.close(() => process.exit(1));
});

process.on('uncaughtException', (err) => {
  console.error('UNCAUGHT EXCEPTION! Shutting down...', err);
  process.exit(1);
});

startServer();