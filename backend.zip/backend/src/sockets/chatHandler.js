export default(io, socket) => {
  // الانضمام لغرفة محادثة معينة
  socket.on("chat:join_room", (roomId) => {
    socket.join(roomId);
    console.log(`User \({socket.id} joined chat room:\){roomId}`);
  });

  // إرسال رسالة داخل الغرفة
  socket.on("chat:send_message", (data) => {
    const { roomId, message, senderId } = data;
    
    // إرسال الرسالة لجميع من في الغرفة باستثناء المرسل (أو للجميع عبر io.to)
    socket.to(roomId).emit("chat:receive_message", {
      senderId,
      message,
      createdAt: new Date().toISOString()
    });
  });

  // حدث الكتابة (Typing indicator)
  socket.on("chat:typing", ({ roomId, isTyping }) => {
    socket.to(roomId).emit("chat:user_typing", {
      userId: socket.id,
      isTyping
    });
  });
};
