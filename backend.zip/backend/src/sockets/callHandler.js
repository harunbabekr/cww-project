export default (io, socket) => {
  // بدء أو طلب مكالمة
  socket.on("call:initiate", ({ toUserId, signalData, callerName }) => {
    io.to(toUserId).emit("call:incoming", {
      from: socket.id,
      signalData,
      callerName
    });
  });

  // قبول المكالمة وإرسال إشارة الرد (Answer)
  socket.on("call:answer", ({ toUserId, signalData }) => {
    io.to(toUserId).emit("call:accepted", {
      signalData,
      from: socket.id
    });
  });

  // تبادل مرشحات ICE (ICE Candidates)
  socket.on("call:ice_candidate", ({ toUserId, candidate }) => {
    io.to(toUserId).emit("call:ice_candidate", {
      candidate,
      from: socket.id
    });
  });

  // إنهاء المكالمة
  socket.on("call:end", ({ toUserId }) => {
    io.to(toUserId).emit("call:ended", { from: socket.id });
  });
};
