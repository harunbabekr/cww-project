import WatchRoom from "../models/WatchRoom.js";

export const createRoom = async (req, res) => {
  try {
    const { title, videoUrl } = req.body;

    const room = await WatchRoom.create({
      title,
      videoUrl,
      host: req.user.id,
      participants: [req.user.id],
      playbackState: { isPlaying: false, currentTime: 0 },
    });

    res.status(201).json(room);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getRoom = async (req, res) => {
  try {
    const room = await WatchRoom.findById(req.params.roomId)
      .populate("host", "name")
      .populate("participants", "name");

    if (!room) return res.status(404).json({ message: "الغرفة غير موجودة" });

    res.json(room);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updatePlaybackState = async (req, res) => {
  try {
    const { roomId } = req.params;
    const { isPlaying, currentTime } = req.body;

    const room = await WatchRoom.findById(roomId);
    if (!room) return res.status(404).json({ message: "الغرفة غير موجودة" });

    if (room.host.toString() !== req.user.id) {
      return res.status(403).json({ message: "فقط المضيف يمكنه التحكم في التشغيل" });
    }

    room.playbackState = { isPlaying, currentTime, lastUpdated: new Date() };
    await room.save();

    res.json(room.playbackState);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};