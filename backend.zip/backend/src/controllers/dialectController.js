import Dialect from "../models/Dialect.js";

export const addDialectEntry = async (req, res) => {
  try {
    const { dialectName, word, standardMeaning, example, audioUrl } = req.body;

    const entry = await Dialect.create({
      dialectName,
      word,
      standardMeaning,
      example,
      audioUrl,
      contributedBy: req.user ? req.user.id : null,
    });

    res.status(201).json(entry);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const searchDialect = async (req, res) => {
  try {
    const { q, dialect } = req.query;
    const filter = {};

    if (dialect) filter.dialectName = dialect;
    if (q) {
      filter.$or = [
        { word: { $regex: q, $options: "i" } },
        { standardMeaning: { $regex: q, $options: "i" } },
      ];
    }

    const results = await Dialect.find(filter).limit(30);
    res.json(results);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getAllDialectsList = async (req, res) => {
  try {
    const dialects = await Dialect.distinct("dialectName");
    res.json(dialects);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};