import Contact from "../models/Contact.js";

export const submitContactForm = async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ message: "يرجى تعبئة الحقول الأساسية" });
    }

    const contact = await Contact.create({
      name,
      email,
      subject,
      message,
      userId: req.user ? req.user.id : null,
      status: "pending",
    });

    res.status(201).json({ message: "تم استلام رسالتك بنجاح", id: contact._id });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getContactMessages = async (req, res) => {
  try {
    const messages = await Contact.find().sort({ createdAt: -1 });
    res.json(messages);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};