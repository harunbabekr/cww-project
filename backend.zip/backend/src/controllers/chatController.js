import Message from "../models/Message.js";
import Conversation from "../models/Conversation.js";

export const sendMessage = async (req, res) => {
  try {
    const { conversationId, text, type = "text", mediaUrl } = req.body;
    const senderId = req.user.id;

    const newMessage = await Message.create({
      conversationId,
      sender: senderId,
      text,
      type,
      mediaUrl,
    });

    await Conversation.findByIdAndUpdate(conversationId, {
      lastMessage: text || "وسائط",
      updatedAt: new Date(),
    });

    res.status(201).json(newMessage);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getMessages = async (req, res) => {
  try {
    const { conversationId } = req.params;
    const { limit = 50, page = 1 } = req.query;

    const messages = await Message.find({ conversationId })
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .populate("sender", "name email");

    res.json(messages.reverse());
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};