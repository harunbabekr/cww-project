// aiConfig.js
import { GoogleGenerativeAI } from '@google/generative-ai';

// التحقق من وجود مفتاح الـ API
if (!process.env.GEMINI_API_KEY) {
  console.error("Warning: GEMINI_API_KEY is not defined in environment variables.");
}

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

// تهيئة النموذج الأساسي مع إعدادات التوليد
export const aiModel = genAI.getGenerativeModel({
  model: 'gemini-1.5-pro',
  generationConfig: {
    temperature: 0.7,
    topP: 0.95,
    maxOutputTokens: 2048,
  },
});

/**
 * دالة مساعدة لتوليد النصوص بسهولة
 * @param {string} prompt - النص المطلوب تحليله أو الرد عليه
 * @returns {Promise<string>}
 */
export const generateText = async (prompt) => {
  try {
    const result = await aiModel.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error generating AI response:', error);
    throw error;
  }
};

export default genAI;