// db.js
import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      // إعدادات Mongoose الموصى بها مسبقاً مدمجة افتراضياً في الإصدارات الحديثة
    });

    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Database Connection Error: ${error.message}`);
    process.exit(1); // إيقاف العملية في حال فشل الاتصال الحرج
  }
};

export default connectDB;