const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema(
  {
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    receiver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      index: true,
    },
    roomId: {
      type: String,
      trim: true,
      index: true, // للمحادثات الجماعية أو غرف WebRTC
    },
    originalText: {
      type: String,
      required: true,
      trim: true,
    },
    translatedText: {
      type: String,
      trim: true,
    },
    sourceLanguage: {
      type: String,
      default: 'auto',
    },
    targetLanguage: {
      type: String,
    },
    mediaUrl: {
      type: String, // روابط صوت أو ملفات مرفقة
    },
    read: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

// فهرس مركب لتسريع جلب سجل المحادثات
messageSchema.index({ roomId: 1, createdAt: -1 });

module.exports = mongoose.model('Message', messageSchema);