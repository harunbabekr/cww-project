const mongoose = require('mongoose');

const dialectDictionarySchema = new mongoose.Schema(
  {
    word: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    dialect: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    standardMeaning: {
      type: String,
      required: true,
      trim: true,
    },
    phoneticSpelling: {
      type: String, // النطق الصوتي أو الكتابة الصوتية
      trim: true,
    },
    examples: [
      {
        type: String,
        trim: true,
      },
    ],
    verified: {
      type: Boolean,
      default: false,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  { timestamps: true }
);

// فهرس مركب للبحث السريع عن الكلمة داخل لهجة محددة وفهرس نصي
dialectDictionarySchema.index({ word: 1, dialect: 1 }, { unique: true });
dialectDictionarySchema.index({ word: 'text', standardMeaning: 'text' });

module.exports = mongoose.model('DialectDictionary', dialectDictionarySchema);