const mongoose = require('mongoose');

const videoContentSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      trim: true,
    },
    videoUrl: {
      type: String,
      required: true,
    },
    thumbnailUrl: {
      type: String,
    },
    duration: {
      type: Number, // المدة بالثواني
      default: 0,
    },
    uploader: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    tags: [
      {
        type: String,
        trim: true,
      },
    ],
    subtitles: [
      {
        language: { type: String, required: true },
        url: { type: String, required: true }, // رابط ملف VTT أو SRT
      },
    ],
    views: {
      type: Number,
      default: 0,
    },
    isPublic: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

videoContentSchema.index({ title: 'text', tags: 'text' });

module.exports = mongoose.model('VideoContent', videoContentSchema);