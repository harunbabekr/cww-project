// كلاس لإنشاء أخطاء تشغيلية محددة الحالة
export class AppError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;

    Error.captureStackTrace(this, this.constructor);
  }
}

// دالة لمعالجة أخطاء مسار غير موجود (404)
export const notFound = (req, res, next) => {
  const error = new AppError(`المسار غير موجود: ${req.originalUrl}`, 404);
  next(error);
};

// Global Error Handler Middleware
export const errorHandler = (err, req, res, next) => {
  let statusCode = err.statusCode || 500;
  let message = err.message || 'حدث خطأ داخلي في الخادم';

  // معالجة خطأ معرف غير صالح في Mongoose (CastError)
  if (err.name === 'CastError') {
    message = `المورد غير موجود بالمعرف المحدد: ${err.value}`;
    statusCode = 404;
  }

  // معالجة خطأ التكرار في الحقول الفريدة (Duplicate Key)
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    message = `القيمة المدخلة في حقل (${field}) مستخدمة بالفعل`;
    statusCode = 400;
  }

  // معالجة أخطاء التحقق من المدخلات (ValidationError)
  if (err.name === 'ValidationError') {
    message = Object.values(err.errors)
      .map((val) => val.message)
      .join('، ');
    statusCode = 400;
  }

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};