import jwt from 'jsonwebtoken';

export const protect = async (req, res, next) => {
  let token;

  const authHeader = req.headers.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'غير مصرح لك بالوصول، لا يوجد رمز توثيق (Token)',
    });
  }

  try {
    // التحقق من صحة الرمز
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // إرفاق بيانات المستخدم بالطلب للاستفادة منها في الـ Controllers اللاحقة
    // decoded يحتوي عادة على { id, role, ... } بحسب ما تم تضمينه عند إنشاء الرمز
    req.user = decoded;

    next();
  } catch (error) {
    let message = 'رمز التوثيق غير صالح';

    if (error.name === 'TokenExpiredError') {
      message = 'انتهت صلاحية رمز التوثيق، يرجى تسجيل الدخول مجدداً';
    }

    return res.status(401).json({
      success: false,
      message,
    });
  }
};

// اختياري: Middleware للتحقق من صلاحيات الأدوار (Roles) مثل 'admin'
export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'ليس لديك الصلاحية الكافية للوصول إلى هذا المورد',
      });
    }
    next();
  };
};