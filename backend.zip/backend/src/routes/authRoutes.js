const express = require('express');
const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    // التحقق والتسجيل
    res.status(201).json({ success: true, message: 'تم إنشاء الحساب بنجاح' });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    // التحقق وتوليد الـ Token
    res.status(200).json({ success: true, token: 'mock-jwt-token' });
  } catch (error) {
    res.status(401).json({ success: false, error: error.message });
  }
});

module.exports = router;