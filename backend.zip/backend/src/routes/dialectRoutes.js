const express = require('express');
const router = express.Router();

router.get('/', async (req, res) => {
  const supportedDialects = [
    { code: 'ar-SD', name: 'اللهجة السودانية', region: 'Sudan' },
    { code: 'ar-EG', name: 'اللهجة المصرية', region: 'Egypt' },
    { code: 'ar-SA', name: 'اللهجة السعودية', region: 'Gulf' }
  ];
  res.status(200).json({ success: true, data: supportedDialects });
});

router.get('/:code/lexicon', async (req, res) => {
  const { code } = req.params;
  // استرجاع معجم الكلمات الخاصة باللهجة
  res.status(200).json({ success: true, dialect: code, entriesCount: 1500 });
});

module.exports = router;