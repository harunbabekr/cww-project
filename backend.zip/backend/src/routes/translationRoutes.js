const express = require('express');
const router = express.Router();
const sttService = require('../services/sttService');
const translationService = require('../services/translationService');
const ttsCloneService = require('../services/ttsCloneService');

// معالجة الترجمة الفورية للنصوص
router.post('/text', async (req, res) => {
  try {
    const { text, from, to } = req.body;
    const result = await translationService.translateText(text, from, to);
    res.status(200).json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// استقبال ملف صوتي، استخراج النص، ترجمته، وتوليده بصوت مستنسخ (Voice Pipeline)
router.post('/voice-pipeline', async (req, res) => {
  try {
    const { fromDialect, toDialect, voiceProfileId } = req.body;
    const rawAudioBuffer = req.body.audioBuffer ? Buffer.from(req.body.audioBuffer, 'base64') : Buffer.from('mock');

    // 1. STT
    const transcript = await sttService.transcribeAudio(rawAudioBuffer, fromDialect);

    // 2. Translation
    const translation = await translationService.translateText(transcript.text, fromDialect, toDialect);

    // 3. TTS Clone
    const clonedAudio = await ttsCloneService.synthesizeClonedVoice(translation.translated, voiceProfileId);

    res.status(200).json({
      success: true,
      data: {
        recognizedText: transcript.text,
        translatedText: translation.translated,
        outputAudioUrl: clonedAudio.audioUrl
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;