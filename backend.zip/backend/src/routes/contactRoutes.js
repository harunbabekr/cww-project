const express = require('express');
const router = express.Router();

router.get('/', async (req, res) => {
  res.status(200).json({ success: true, contacts: [] });
});

router.post('/add', async (req, res) => {
  try {
    const { contactUserId } = req.body;
    res.status(200).json({ success: true, message: 'تمت إضافة جهة الاتصال' });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

module.exports = router;