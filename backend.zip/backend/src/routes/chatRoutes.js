const express = require('express');
const router = express.Router();

router.get('/conversations', async (req, res) => {
  res.status(200).json({ success: true, conversations: [] });
});

router.post('/messages', async (req, res) => {
  try {
    const { conversationId, content, mediaType } = req.body;
    res.status(201).json({
      success: true,
      message: { id: 'msg_101', conversationId, content, mediaType, createdAt: new Date() }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;