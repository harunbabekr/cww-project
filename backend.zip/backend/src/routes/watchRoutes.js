const express = require('express');
const router = express.Router();

router.post('/rooms', async (req, res) => {
  try {
    const { title, mediaUrl } = req.body;
    res.status(201).json({
      success: true,
      room: { roomId: 'room_882', title, mediaUrl, hostId: 'user_1' }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/rooms/:id', async (req, res) => {
  res.status(200).json({
    success: true,
    room: { roomId: req.params.id, status: 'active', viewersCount: 1 }
  });
});

module.exports = router;