import express from 'express';
import cors from 'cors';

const app = express();

// إعدادات الـ Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// مسار فحص الحالة (Health Check)
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'success', message: 'Server is healthy' });
});

// مثال لربط مسارات أخرى
// import apiRoutes from './routes/index.js';
// app.use('/api', apiRoutes);

// معالجة المسارات غير الموجودة (404)
app.use((req, res, next) => {
  res.status(404).json({ error: 'Route not found' });
});

// Middleware مركزي لمعالجة الأخطاء
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error'
  });
});

export default app;