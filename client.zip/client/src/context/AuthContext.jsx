import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api.js';
import socketService from '../services/socket.js';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem('cww_token');
      if (token) {
        try {
          const res = await api.get('/auth/me');
          setUser(res.data.user);
          socketService.connect(token);
        } catch (err) {
          localStorage.removeItem('cww_token');
        }
      }
      setLoading(false);
    };

    checkAuth();
  }, []);

  const login = async (email, password) => {
    const res = await api.post('/auth/login', { email, password });
    localStorage.setItem('cww_token', res.data.token);
    setUser(res.data.user);
    socketService.connect(res.data.token);
  };

  const logout = () => {
    localStorage.removeItem('cww_token');
    socketService.disconnect();
    setUser(null);
  };

  if (loading) {
    return null;
  }

  return (
    
      {children}
    
  );
};

export const useAuth = () => useContext(AuthContext);