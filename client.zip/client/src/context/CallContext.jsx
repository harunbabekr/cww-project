import React, { createContext, useContext, useState, useEffect } from 'react';
import socketService from '../services/socket';
import webrtcService from '../services/webrtc';

const CallContext = createContext();

export const CallProvider = ({ children }) => {
  const [incomingCall, setIncomingCall] = useState(null);
  const [activeCall, setActiveCall] = useState(false);
  const [remoteStream, setRemoteStream] = useState(null);

  useEffect(() => {
    const socket = socketService.getSocket();
    if (!socket) return;

    socket.on('call:incoming', (data) => {
      setIncomingCall(data);
    });

    socket.on('call:accepted', async ({ signalData }) => {
      await webrtcService.handleAnswer(signalData);
      setActiveCall(true);
    });

    socket.on('call:ice_candidate', async ({ candidate }) => {
      await webrtcService.addIceCandidate(candidate);
    });

    socket.on('call:ended', () => {
      webrtcService.close();
      setActiveCall(false);
      setIncomingCall(null);
      setRemoteStream(null);
    });

    return () => {
      socket.off('call:incoming');
      socket.off('call:accepted');
      socket.off('call:ice_candidate');
      socket.off('call:ended');
    };
  }, []);

  const answerCall = async () => {
    const peer = webrtcService.createPeer(
      (stream) => setRemoteStream(stream),
      (candidate) => {
        socketService.getSocket().emit('call:ice_candidate', {
          toUserId: incomingCall.from,
          candidate
        });
      }
    );
    await webrtcService.initLocalStream();
    await peer.setRemoteDescription(new RTCSessionDescription(incomingCall.signalData));
    const answer = await peer.createAnswer();
    await peer.setLocalDescription(answer);

    socketService.getSocket().emit('call:answer', {
      toUserId: incomingCall.from,
      signalData: answer
    });

    setActiveCall(true);
  };

  return (
    
      {children}
    
  );
};

export const useCall = () => useContext(CallContext);