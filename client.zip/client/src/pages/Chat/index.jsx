
import React, { useState, useEffect } from 'react';
import { Send, Globe, Radio } from 'lucide-react';
import socketService from '../../services/socket';

export const Chat = () => {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [selectedDialect, setSelectedDialect] = useState('ar-SD');

  const socket = socketService.getSocket();

  useEffect(() => {
    if (!socket) return;

    socket.emit('chat:join_room', 'cww-global-dialect-room');

    socket.on('chat:receive_message', (payload) => {
      setMessages((prev) => [...prev, payload]);
    });

    return () => {
      socket.off('chat:receive_message');
    };
  }, [socket]);

  const handleSend = () => {
    if (!text.trim()) return;

    const payload = {
      roomId: 'cww-global-dialect-room',
      message: text,
      dialect: selectedDialect,
      senderId: socket?.id
    };

    socket?.emit('chat:send_message', payload);
    setMessages((prev) => [...prev, { ...payload, self: true }]);
    setText('');
  };

  return (
    <div>
      <h2>غرفة الترجمة النصية الحية المفتوحة</h2>

      <div>
        <Globe />
        <span>اللهجة المحددة: {selectedDialect}</span>
      </div>

      <div>
        {messages.map((msg, index) => (
          <div key={index}>
            <div>
              <Radio />
              <span>{msg.dialect || 'لهجة محددة'}</span>
            </div>

            <p>{msg.message}</p>
          </div>
        ))}
      </div>

      <div>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="اكتب رسالتك وسيتكفل المحرك بتحليلها وترجمتها..."
          style={{
            flex: 1,
            backgroundColor: 'var(--bg-surface)',
            border: '1px solid var(--border-subtle)',
            borderRadius: '12px',
            padding: '14px 18px',
            color: '#fff',
            outline: 'none',
            fontSize: '1rem'
          }}
        />

        <button type="button" onClick={handleSend}>
          <Send />
        </button>
      </div>
    </div>
  );
};

