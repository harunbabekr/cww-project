
import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Languages,
  Volume2,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import socketService from '../../services/socket';

export const RealTimeFaceToFace = () => {
  const [isListening, setIsListening] = useState(false);
  const [sourceLang, setSourceLang] = useState('ar-SD');
  const [targetLang, setTargetLang] = useState('en-US');
  const [recognizedText, setRecognizedText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);

  const socket = socketService.getSocket();

  useEffect(() => {
    if (!socket) return;

    socket.on('stt:result', (data) => {
      setRecognizedText(data.text);
    });

    socket.on('translation:result', (data) => {
      setTranslatedText(data.translated);
      setIsTranslating(false);
    });

    return () => {
      socket.off('stt:result');
      socket.off('translation:result');
    };
  }, [socket]);

  const toggleListening = () => {
    setIsListening((prev) => !prev);

    if (!isListening) {
      setIsTranslating(true);
      socket?.emit('stt:start_stream', {
        dialect: sourceLang,
        target: targetLang
      });
    } else {
      socket?.emit('stt:stop_stream');
      setIsTranslating(false);
    }
  };

  return (
    <div>
      {/* جهة المتحدث المحلي */}
      <section>
        <h2>المتحدث الأول</h2>

        <p>
          {recognizedText ||
            'ابدأ بالتحدث لتوليد الكلمات بدقة اللهجة المحلية...'}
        </p>

        <button onClick={toggleListening}>
          {isListening ? <MicOff /> : <Mic />}
        </button>
      </section>

      {/* جهة المترجم الفوري المستنسخ */}
      <section>
        {isTranslating && <RefreshCw />}

        <p>
          {translatedText ||
            'الترجمة الفورية المطابقة للبصمة الصوتية ستظهر هنا...'}
        </p>

        <button type="button">
          <Volume2 />
          تشغيل الصوت المستنسخ
        </button>
      </section>
    </div>
  );
};

