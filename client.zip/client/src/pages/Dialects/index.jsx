
import React, { useState } from 'react';
import { Search, Plus, CheckCircle2 } from 'lucide-react';

export const Dialects = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const [lexicon] = useState([
    {
      word: 'آي',
      dialect: 'السودانية',
      meaning: 'نعم / بالتأكيد',
      examples: ['آي، أنا جاهز']
    },
    {
      word: 'قوام',
      dialect: 'السودانية',
      meaning: 'بسرعة فائقة',
      examples: ['تعال قوام']
    },
    {
      word: 'برضو',
      dialect: 'المصرية / الشامية',
      meaning: 'أيضاً',
      examples: ['أنا برضو هنا']
    }
  ]);

  return (
    <div>
      <div>
        <h2>معجم المصطلحات واللهجات الحية</h2>

        <p>
          قاعدة البيانات المعجمية المغذية لنموذج الترجمة وتوليد الصوت
        </p>

        <button type="button">
          <Plus />
          إضافة مصطلح
        </button>
      </div>

      <div>
        <div>
          <Search />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ابحث عن كلمة، معنى، أو لهجة محددة..."
            style={{
              width: '100%',
              padding: '14px 48px 14px 18px',
              backgroundColor: 'var(--bg-surface)',
              border: '1px solid var(--border-subtle)',
              borderRadius: '14px',
              color: '#fff',
              outline: 'none',
              fontSize: '1rem'
            }}
          />
        </div>
      </div>

      <div>
        {lexicon.map((item, idx) => (
          <div key={idx}>
            <div>
              <h3>{item.word}</h3>

              <span>
                {item.dialect}
              </span>
            </div>

            <p>{item.meaning}</p>

            <div>
              <CheckCircle2 />
              <span>
                مثال: {item.examples[0]}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

