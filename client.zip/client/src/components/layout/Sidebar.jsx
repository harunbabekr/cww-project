
import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Zap,
  MessageSquareCode,
  Video,
  BookA,
  Clapperboard,
  Contact2,
  LogOut
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const navigationLinks = [
  { name: 'مباشر وجه لوجه', path: '/', icon: Zap },
  { name: 'الترجمة الحية', path: '/chat', icon: MessageSquareCode },
  { name: 'المكالمات المشفرة', path: '/calls', icon: Video },
  { name: 'قاموس اللهجات', path: '/dialects', icon: BookA },
  { name: 'غرف المشاهدة', path: '/watch', icon: Clapperboard },
  { name: 'جهات الاتصال', path: '/contacts', icon: Contact2 },
];

export const Sidebar = () => {
  const { logout } = useAuth();

  return (
    <aside>
      {navigationLinks.map((link) => {
        const Icon = link.icon;

        return (
          <NavLink key={link.path} to={link.path}>
            <Icon />
            <span>{link.name}</span>
          </NavLink>
        );
      })}

      <button onClick={logout}>
        <LogOut />
        <span>تسجيل الخروج</span>
      </button>
    </aside>
  );
};

