
import React from 'react';
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate
} from 'react-router-dom';

import { AuthProvider, useAuth } from './context/AuthContext';
import { CallProvider } from './context/CallContext';
import { Sidebar } from './components/layout/Sidebar';

import { RealTimeFaceToFace } from './pages/RealTimeFaceToFace';
import { Chat } from './pages/Chat';
import { Dialects } from './pages/Dialects';

const AppLayout = ({ children }) => {
  const { user } = useAuth();

  return (
    <div>
      <Sidebar />
      <main>
        {children}
      </main>
    </div>
  );
};

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <CallProvider>
          <AppLayout>
            <Routes>
              <Route
                path="/"
                element={<RealTimeFaceToFace />}
              />

              <Route
                path="/chat"
                element={<Chat />}
              />

              <Route
                path="/dialects"
                element={<Dialects />}
              />

              <Route
                path="*"
                element={<Navigate to="/" replace />}
              />
            </Routes>
          </AppLayout>
        </CallProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

